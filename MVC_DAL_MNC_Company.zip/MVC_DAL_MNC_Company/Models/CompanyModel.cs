﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC_DAL_MNC_Company.Models
{
    public class CompanyModel
    {
        [Display(Name = "Company ID")]
        public int CompanyID { get; set; }

        [Display(Name = "Company Name")]
        public string CompanyName { get; set; }

        [Display(Name = "Company Image")]
        public string CompanyImage { get; set; }

        [Display(Name = "Company Established Year")]
        public int CompanyEstablishedYear { get; set; }

        [Display(Name = "Company Founder")]
        public string CompanyFounder { get; set; }

        [Display(Name = "Company Image File")]
        public HttpPostedFileBase CompanyImageFile { get; set; }
    }
}