﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC_DAL_MNC_Company.Models
{
    public class EmployeeModel
    {
        [Display(Name = "Employee ID")]
        public int EmployeeID { get; set; }

        [Display(Name = "Employee First Name")]
        public string EmployeeFirstName { get; set; }

        [Display(Name = "Employee Last Name")]
        public string EmployeeLastName { get; set; }

        [Display(Name = "Employee Gender")]
        public string EmployeeGender { get; set; }

        [Display(Name = "Employee Image")]
        public string EmployeeImage { get; set; }

        [Display(Name = "Employee DOJ")]
        public DateTime EmployeeDOJ { get; set; }

        [Display(Name = "Employee DOB")]
        public DateTime EmployeeDOB { get; set; }

        [Display(Name = "Employee Permanent Address")]
        public string EmployeePermanentAddress { get; set; }

        [Display(Name = "Employee Designation")]
        public string EmployeeDesignation { get; set; }

        [Display(Name = "Employee Section")]
        public string EmployeeSection { get; set; }

        [Display(Name = "Employee Working Status")]
        public string EmployeeWorkingStatus { get; set; }

        [Display(Name = "Company Branch ID")]
        public int CompanyBranchID { get; set; }

        [Display(Name = "Employee Image File")]
        public HttpPostedFileBase EmployeeImageFile { get; set; }
    }
}