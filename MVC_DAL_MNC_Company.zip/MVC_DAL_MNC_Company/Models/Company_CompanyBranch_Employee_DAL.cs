﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Mvc;

namespace MVC_DAL_MNC_Company.Models
{
    public class Company_CompanyBranch_Employee_DAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddCompany(CompanyModel model)
        {
            try
            {
                SqlCommand com_addcompany = new SqlCommand("proc_addcompany", con);
                com_addcompany.Parameters.AddWithValue("@CompanyName", model.CompanyName);
                com_addcompany.Parameters.AddWithValue("@CompanyImage", model.CompanyImage);
                com_addcompany.Parameters.AddWithValue("@CompanyEstDate", model.CompanyEstablishedYear);
                com_addcompany.Parameters.AddWithValue("@CompanyFounder", model.CompanyFounder);
                com_addcompany.CommandType = CommandType.StoredProcedure;
                SqlParameter para_ret = new SqlParameter();
                para_ret.Direction = ParameterDirection.ReturnValue;
                com_addcompany.Parameters.Add(para_ret);
                con.Open();
                com_addcompany.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_ret.Value);
                return id;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SelectListItem> GetCompanyBranchCountry()
        {
            SqlCommand com_country = new SqlCommand("proc_getCountry", con);
            com_country.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_country.ExecuteReader();
            List<SelectListItem> country = new List<SelectListItem>();
            country.Add(new SelectListItem { Text = "Select", Value = "" });
            while (dr.Read())
            {
                country.Add(new SelectListItem { Text = dr.GetString(0), Value = dr.GetString(0)});
            }
            con.Close();
            return country;

        }
        public List<string> GetCompanyBranchState(string country)
        {
            SqlCommand com_state = new SqlCommand("proc_getstate", con);
            com_state.Parameters.AddWithValue("@country", country);
            com_state.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_state.ExecuteReader();
            List<string> states = new List<string>();
            while (dr.Read())
            {
                states.Add(dr.GetString(0));
            }
            con.Close();
            return states;

        }
        public List<SelectListItem> GetStateCountry()
        {
            SqlCommand com_country = new SqlCommand("proc_getState_country", con);
            com_country.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_country.ExecuteReader();
            List<SelectListItem> country = new List<SelectListItem>();
            while (dr.Read())
            {
                country.Add(new SelectListItem { Text = dr.GetString(0), Value = dr.GetString(0) });
            }
            con.Close();
            return country;

        }
        public List<string> GetState(string country)
        {
            SqlCommand com_state = new SqlCommand("proc_getState_state", con);
            com_state.Parameters.AddWithValue("@country", country);
            com_state.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_state.ExecuteReader();
            List<string> state = new List<string>();
            while (dr.Read())
            {
                state.Add(dr.GetString(0) );
            }
            con.Close();
            return state;

        }
        public List<SelectListItem> GetCompanyBranchCity()
        {
            List<SelectListItem> cities = new List<SelectListItem>();
            cities.Add(new SelectListItem { Text = "Select", Value = "" });
            cities.Add(new SelectListItem { Text = "BGL", Value = "BGL" });
            cities.Add(new SelectListItem { Text = "Vijayawada", Value = "Vijayawada" });
            cities.Add(new SelectListItem { Text = "Los Angeles", Value = "Los Angeles" });
            cities.Add(new SelectListItem { Text = "Buffalo", Value = "Buffalo" });
            cities.Add(new SelectListItem { Text = "Melbourne", Value = "Melbourne" });
            cities.Add(new SelectListItem { Text = "Hobart", Value = "Hobart" });
            cities.Add(new SelectListItem { Text = "Hamilton", Value = "Hamilton" });
            cities.Add(new SelectListItem { Text = "Stratford", Value = "Stratford" });
            cities.Add(new SelectListItem { Text = "Laguna", Value = "Laguna" });
            cities.Add(new SelectListItem { Text = "Lynn Haven", Value = "Lynn Haven" });
            return cities;

        }
        public List<SelectListItem> GetEmployeeDesignation()
        {
            List<SelectListItem> designation = new List<SelectListItem>();
            designation.Add(new SelectListItem { Text = "Select", Value = "" });
            designation.Add(new SelectListItem { Text = "Employee", Value = "Employee" });
            designation.Add(new SelectListItem { Text = "Manager", Value = "Manager" });
            designation.Add(new SelectListItem { Text = "Sub Manager", Value = "Sub Manager" });
            return designation;
        }
        public List<SelectListItem> GetEmployeeSection()
        {
            List<SelectListItem> section = new List<SelectListItem>();
            section.Add(new SelectListItem { Text = "Select", Value = "" });
            section.Add(new SelectListItem { Text = "HR", Value = "HR" });
            section.Add(new SelectListItem { Text = "Marketing", Value = "Marketing" });
            section.Add(new SelectListItem { Text = "Finance", Value = "Finance" });
            section.Add(new SelectListItem { Text = "Accounting", Value = "Accounting" });
            return section;
        }
        public List<SelectListItem> GetEmployeeWorkingStatus()
        {
            List<SelectListItem> workingstatus = new List<SelectListItem>();
            workingstatus.Add(new SelectListItem { Text = "Select", Value = "" });
            workingstatus.Add(new SelectListItem { Text = "Employee", Value = "Employee" });
            workingstatus.Add(new SelectListItem { Text = "Contract", Value = "Contract" });
            workingstatus.Add(new SelectListItem { Text = "Resigned", Value = "Resigned" });
            workingstatus.Add(new SelectListItem { Text = "Trainee", Value = "Trainee" });
            return workingstatus;
        }
        public List<SelectListItem> GetCompanyBranchID()
        {
            SqlCommand com_branchid = new SqlCommand("proc_getbranchdetails", con);
            com_branchid.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_branchid.ExecuteReader();
            List<SelectListItem> list = new List<SelectListItem>();
            while (dr.Read())
            {
                list.Add(new SelectListItem { Text = dr.GetInt32(0).ToString(), Value = dr.GetInt32(0).ToString() });
            }
            con.Close();
            return list;
        }
        public int AddCompanyBranch(CompanyBranchModel model)
        {
            try
            {
                SqlCommand com_addcompanybranch = new SqlCommand("proc_addcompanybranch", con);
                com_addcompanybranch.Parameters.AddWithValue("@CompanyID", model.CompanyID);
                com_addcompanybranch.Parameters.AddWithValue("@CompanyBranchCountry", model.CompanyBranchCountry);
                com_addcompanybranch.Parameters.AddWithValue("@CompanyBranchState", model.CompanyBranchState);
                com_addcompanybranch.Parameters.AddWithValue("@CompanyBranchCity", model.CompanyBranchCity);
                com_addcompanybranch.Parameters.AddWithValue("@CompanyBranchAddress", model.CompanyBranchAddress);
                com_addcompanybranch.Parameters.AddWithValue("@CompanyBranchContactNumber", model.CompanyBranchContactNumber);
                com_addcompanybranch.CommandType = CommandType.StoredProcedure;
                SqlParameter para_ret = new SqlParameter();
                para_ret.Direction = ParameterDirection.ReturnValue;
                com_addcompanybranch.Parameters.Add(para_ret);
                con.Open();
                com_addcompanybranch.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_ret.Value);
                return id;
            }
            finally
            {
                con.Close();
            }
        }
        public int AddEmployee(EmployeeModel model)
        {
            try
            {
                SqlCommand com_addemployee = new SqlCommand("proc_addemployees", con);
                com_addemployee.Parameters.AddWithValue("@EmployeeFirstName", model.EmployeeFirstName);
                com_addemployee.Parameters.AddWithValue("@EmployeeLastName", model.EmployeeLastName);
                com_addemployee.Parameters.AddWithValue("@EmployeeGender", model.EmployeeGender);
                com_addemployee.Parameters.AddWithValue("@EmployeeImage", model.EmployeeImage);
                com_addemployee.Parameters.AddWithValue("@EmployeeDOJ", model.EmployeeDOJ);
                com_addemployee.Parameters.AddWithValue("@EmployeeDOB", model.EmployeeDOB);
                com_addemployee.Parameters.AddWithValue("@EmployeePermanentAddress", model.EmployeePermanentAddress);
                com_addemployee.Parameters.AddWithValue("@EmployeeDesignation", model.EmployeeDesignation);
                com_addemployee.Parameters.AddWithValue("@EmployeeSection", model.EmployeeSection);
                com_addemployee.Parameters.AddWithValue("@EmployeeWorkingStatus", model.EmployeeWorkingStatus);
                com_addemployee.Parameters.AddWithValue("@CompanyBranchID", model.CompanyBranchID);
                com_addemployee.CommandType = CommandType.StoredProcedure;
                SqlParameter para_ret = new SqlParameter();
                para_ret.Direction = ParameterDirection.ReturnValue;
                com_addemployee.Parameters.Add(para_ret);
                con.Open();
                com_addemployee.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_ret.Value);
                return id;
            }
            finally
            {
                con.Close();
            }
        }
        public List<EmployeeModel> Search(string Country,string State,string Section)
        {
                SqlCommand com_search = new SqlCommand("proc_search", con);
                com_search.Parameters.AddWithValue("@Country", Country);
                com_search.Parameters.AddWithValue("@State", State);
                com_search.Parameters.AddWithValue("@Section", Section);
                com_search.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader dr = com_search.ExecuteReader();
                List<EmployeeModel> list = new List<EmployeeModel>();
                while (dr.Read())
                {
                    EmployeeModel model = new EmployeeModel();
                    model.EmployeeID = dr.GetInt32(0);
                    model.EmployeeFirstName = dr.GetString(1);
                    model.EmployeeLastName = dr.GetString(2);
                    model.EmployeeGender = dr.GetString(3);
                    model.EmployeeImage = dr.GetString(4);
                    model.EmployeeDOJ = dr.GetDateTime(5);
                    model.EmployeeDOB = dr.GetDateTime(6);
                    model.EmployeePermanentAddress = dr.GetString(7);
                    model.EmployeeDesignation = dr.GetString(8);
                    model.EmployeeSection = dr.GetString(9);
                    model.EmployeeWorkingStatus = dr.GetString(10);
                    model.CompanyBranchID = dr.GetInt32(11);
                    list.Add(model);
                }
            con.Close();
            return list;
        }
    }
}