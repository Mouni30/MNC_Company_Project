﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC_DAL_MNC_Company.Models
{
    public class CompanyBranchModel
    {
        [Display(Name = "Company Branch ID")]
        public int CompanyBranchID { get; set; }

        [Display(Name = "Company ID")]
        public int CompanyID { get; set; }

        [Display(Name = "Company Branch Country")]
        public string CompanyBranchCountry { get; set; }

        [Display(Name = "Company Branch State")]
        public string CompanyBranchState { get; set; }

        [Display(Name = "Company Branch City")]
        public string CompanyBranchCity { get; set; }

        [Display(Name = "Company Branch Address")]
        public string CompanyBranchAddress { get; set; }

        [Display(Name = "Company Branch Contact Number")]
        public string CompanyBranchContactNumber { get; set; }
    }
}