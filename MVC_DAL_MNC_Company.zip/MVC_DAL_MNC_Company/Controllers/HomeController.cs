﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_DAL_MNC_Company.Models;

namespace MVC_DAL_MNC_Company.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.msg = "Company Details";
            return View();
        }
        public ActionResult AddCompany()
        {
            return View();
        }
        [HttpPost]
        public ActionResult AddCompany(CompanyModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    model.CompanyImage = "/Images/" + Guid.NewGuid() + ".jpg";
                    model.CompanyImageFile.SaveAs(Server.MapPath(model.CompanyImage));
                    Company_CompanyBranch_Employee_DAL dal = new Company_CompanyBranch_Employee_DAL();
                    int id = dal.AddCompany(model);
                    ViewBag.msg = "Company Added : " + id;
                    ModelState.Clear();
                    return View();
                }
                else
                {
                    return View();
                }
            }
            catch(Exception e)
            {
                
                return View(e);
            }

        }
        public ActionResult AddCompanyBranch()
        {
            Company_CompanyBranch_Employee_DAL dal = new Company_CompanyBranch_Employee_DAL();
            ViewBag.country = dal.GetCompanyBranchCountry();
            return View();
        }
        [HttpPost]
        public ActionResult AddCompanyBranch(CompanyBranchModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    Company_CompanyBranch_Employee_DAL dal = new Company_CompanyBranch_Employee_DAL();
                    int id = dal.AddCompanyBranch(model);
                    ViewBag.msg = "Company Branch Added : " + id;
                    ModelState.Clear();
                    ViewBag.country = dal.GetCompanyBranchCountry();
                    return View();
                }
                else
                {
                    Company_CompanyBranch_Employee_DAL dal = new Company_CompanyBranch_Employee_DAL();
                    ViewBag.country = dal.GetCompanyBranchCountry();
                    return View();
                }
            }
            catch(Exception e)
            {
                return View(e);
            }
        }
        public ActionResult AddEmployee()
        {
            Company_CompanyBranch_Employee_DAL dal = new Company_CompanyBranch_Employee_DAL();
            ViewBag.designation = dal.GetEmployeeDesignation();
            ViewBag.section = dal.GetEmployeeSection();
            ViewBag.workingstatus = dal.GetEmployeeWorkingStatus();
            ViewBag.list = dal.GetCompanyBranchID();
            return View();
        }
        [HttpPost]
        public ActionResult AddEmployee(EmployeeModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    model.EmployeeImage = "/Images/" + Guid.NewGuid() + ".jpg";
                    model.EmployeeImageFile.SaveAs(Server.MapPath(model.EmployeeImage));
                    Company_CompanyBranch_Employee_DAL dal = new Company_CompanyBranch_Employee_DAL();
                    int id = dal.AddEmployee(model);
                    ViewBag.msg = "Employee Added : " + id;
                    ModelState.Clear();
                    ViewBag.designation = dal.GetEmployeeDesignation();
                    ViewBag.section = dal.GetEmployeeSection();
                    ViewBag.workingstatus = dal.GetEmployeeWorkingStatus();
                    ViewBag.list = dal.GetCompanyBranchID();
                    return View();
                }
                else
                {
                    Company_CompanyBranch_Employee_DAL dal = new Company_CompanyBranch_Employee_DAL();
                    ViewBag.designation = dal.GetEmployeeDesignation();
                    ViewBag.section = dal.GetEmployeeSection();
                    ViewBag.workingstatus = dal.GetEmployeeWorkingStatus();
                    ViewBag.list = dal.GetCompanyBranchID();
                    return View();
                }
            }
            catch(Exception e)
            {
                return View(e);
            }
        }
        public ActionResult Search()
        {
            Company_CompanyBranch_Employee_DAL dal = new Company_CompanyBranch_Employee_DAL();
            ViewBag.country = dal.GetCompanyBranchCountry();

            List<EmployeeModel> list = new List<EmployeeModel>();
            return View(list);
        }

        [Route("Home/GetStates/{Country}")]
        public ActionResult GetStates(string Country)
        {
            Company_CompanyBranch_Employee_DAL dal = new Company_CompanyBranch_Employee_DAL();
            List<string> states = dal.GetCompanyBranchState(Country);
                
            return Json(states, JsonRequestBehavior.AllowGet);
        }
        [Route("Home/GetState/{Countries}")]
        public ActionResult GetState(string Countries)
        {
            Company_CompanyBranch_Employee_DAL dal = new Company_CompanyBranch_Employee_DAL();
            List<string> state = dal.GetCompanyBranchState(Countries);

            return Json(state, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Search(string Country, string State, string Section)
        {
            Company_CompanyBranch_Employee_DAL dal = new Company_CompanyBranch_Employee_DAL();
            List<EmployeeModel> list = dal.Search(Country, State, Section);
            ViewBag.country = dal.GetCompanyBranchCountry();
            return View(list);
        }
    }
}
