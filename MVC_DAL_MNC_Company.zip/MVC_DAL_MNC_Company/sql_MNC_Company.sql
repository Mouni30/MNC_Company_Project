create database MNC_Company

use MNC_Company

--Company Table

create table tbl_company
(
CompanyID int identity(1,1) primary key,
CompanyName varchar(100) not null,
CompanyImage varchar(100) not null,
CompanyEstablishedYear int not null,
CompanyFounder varchar(100) not null
)

--Company Branch Table

create table tbl_companybranch
(
CompanyBranchID int identity(100,1) primary key,
CompanyID int foreign key references tbl_company(CompanyID),
CompanyBranchCountry varchar(100) not null,
CompanyBranchState varchar(100) not null,
CompanyBranchCity varchar(100) not null,
CompanyBranchAddress varchar(100) not null,
CompanyBranchContactNumber varchar(15) not null
)

--Employees Table

create table tbl_employees
(
EmployeeID int identity(1000,1) primary key,
EmployeeFirstName varchar(100) not null,
EmployeeLastName varchar(100) not null,
EmployeeGender varchar(100) not null,
EmployeeImage varchar(100) not null,
EmployeeDOJ datetime not null,
EmployeeDOB datetime not null,
EmployeePermanentAddress varchar(100) not null,
EmployeeDesignation varchar(100) not null,
EmployeeSection varchar(100) not null,
EmployeeWorkingStatus varchar(100) not null,
CompanyBranchID int foreign key references tbl_companybranch(CompanyBranchID)
)

--countries

create table tbl_state
(
stateid int identity(10,1) primary key,
StateName varchar(100),
countryname varchar(100),
) 

--Add Company

create proc proc_addcompany
(@CompanyName varchar(100),@CompanyImage varchar(100),@CompanyEstDate int,
@CompanyFounder varchar(100))
as
begin
insert tbl_company values(@CompanyName,@CompanyImage,@CompanyEstDate,@CompanyFounder)
return @@identity
end

--Add Company Branch

create proc proc_addcompanybranch
(@CompanyID int,@CompanyBranchCountry varchar(100),@CompanyBranchState varchar(100),
@CompanyBranchCity varchar(100),@CompanyBranchAddress varchar(100),
@CompanyBranchContactNumber varchar(15))
as
begin
declare @count int
select @count=count(*) from tbl_companybranch where
CompanyID=@CompanyID and CompanyBranchID=@@identity
if(@count=0)
begin
insert tbl_companybranch values(@CompanyID,@CompanyBranchCountry,@CompanyBranchState,@CompanyBranchCity,
@CompanyBranchAddress,@CompanyBranchContactNumber)
end
return @@rowcount
end

select * from tbl_employees
--Add Employees

create proc proc_addemployees
(@EmployeeFirstName varchar(100),@EmployeeLastName varchar(100),@EmployeeGender varchar(100),
@EmployeeImage varchar(100),@EmployeeDOJ datetime,@EmployeeDOB datetime,
@EmployeePermanentAddress varchar(100),@EmployeeDesignation varchar(100),@EmployeeSection varchar(100),
@EmployeeWorkingStatus varchar(100),@CompanyBranchID int)
as
begin
declare @count int
select @count=count(*) from tbl_employees where
EmployeeID=@@identity and CompanyBranchID=@CompanyBranchID
if(@count=0)
begin
insert tbl_employees values(@EmployeeFirstName,@EmployeeLastName,@EmployeeGender,@EmployeeImage,
@EmployeeDOJ,@EmployeeDOB,@EmployeePermanentAddress,@EmployeeDesignation,@EmployeeSection,
@EmployeeWorkingStatus,@CompanyBranchID)
end
return @@rowcount
end


--Search 

create proc proc_search
(@Country varchar(100),@State varchar(100),@Section varchar(100))
as
begin
select * from tbl_employees where CompanyBranchID in(select CompanyBranchID from tbl_companybranch where
CompanyBranchCountry=@Country and CompanyBranchState=@State) and EmployeeSection=@Section
return @@rowcount
end


create proc proc_getbranchdetails
as
begin
select CompanyBranchID from tbl_companybranch 
end

create proc proc_getCountry
as begin
select distinct CompanyBranchCountry from tbl_companybranch
end


create proc proc_getstate
(@country varchar(100))
as begin
select distinct CompanyBranchState from tbl_companybranch where CompanyBranchCountry=@country
end

































